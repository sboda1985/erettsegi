#include <iostream>
#include <string>

using namespace std;

int main(int argc, char const *argv[])
{
	string a;
	string b;
	string aux = "";

	cin >> a;
	cin >> b;

	bool van = false;

	for(int i = a.size() - 1; i >= 0; i--)
	{
		aux += a[i];
		bool kiir = true;

		for(int j = 0; j < aux.size(); j++)
		{
			if(aux[aux.size() - j - 1] != b[j])
			{
				kiir = false;
				break;
			}
		}

		if(kiir)
		{
			for(int j = aux.size() - 1; j >= 0; j--)
			{
				cout << aux[j];
			}

			cout << endl;

			van = true;
		}
	}

	if(!van)
	{
		cout << "NU EXISTA";
	}

	return 0;
}