#include <iostream>

using namespace std;

/*bool novekvoSorrend(int num)
{
	int prev = 10;

	while(num != 0 && prev >= num % 10)
	{
		prev = num % 10;
		num /= 10;
	}

	if(num == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}*/

void kiIr(int x)
{
	for(int i = 1; i <= 9 - x; i++)
	{
		int num = i;

		for(int j = i + x; j <= 9; j += x)
		{
			num *= 10;
			num += j;
		}

		cout << num << endl;
	}
}

int main(int argc, char const *argv[])
{
	int x;
	cin >> x;

	kiIr(x);

	return 0;
}