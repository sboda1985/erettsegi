#include <iostream>

using namespace std;

void dublu(int &n, int v[])
{
	int i = 0;

	while(i < n)
	{
		if(v[i] > 0)
		{
			for(int j = n - 1; j >= i + 1; j--)
			{
				v[j + 1] = v[j];
			}

			v[i + 1] = v[i];

			i += 2;
			n++;
		}
		else
		{
			i++;
		}
	}
}

int main(int argc, char const *argv[])
{
	int n;
	int v[98];

	cin >> n;

	for(int i = 0; i < n; i++)
	{
		cin >> v[i];
	}

	dublu(n, v);

	cout << n << endl;
	
	for(int i = 0; i < n; i++)
	{
		cout << v[i] << " ";
	}

	return 0;
}