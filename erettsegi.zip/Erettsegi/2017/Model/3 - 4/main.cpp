#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int x;
    int y;

    cin >> x;
    cin >> y;

    ofstream outputFile;
    outputFile.open("bac.txt");

    int prev = y;
    outputFile << y << " ";

    while(prev > x)
    {
        if(y % 2 == 0)
        {
            prev = y - 1;
        }
        else
        {
            prev =(y + 1) / 2;
        }

        outputFile << prev << " ";
        y = prev;
    }

    outputFile.close();

    return 0;
}
