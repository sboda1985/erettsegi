#include <iostream>
#include <fstream>

using namespace std;

int f(int n)
{
	if(n == 1)
	{
		return 1;
	}
	else
	{
		if(n % 2 == 1)
		{
			return 1 + 2 * f(n - 2);
		}
		else
		{
			return 1 + f(n - 1);
		}
	}
}

void kiIr(int x)
{
	ofstream outputFile;
	outputFile.open("bac.txt");

	for(int i = x; i > 0; i--)
	{
		int num = f(i);

		if(num <= x)
		{
			outputFile << num << " ";
		}
	}
}

int main(int argc, char const *argv[])
{
	int x = 15;

	kiIr(x);

	return 0;
}