#include <iostream>

using namespace std;

bool egyenlo(int j, int m, int arr[50][50])
{
	for(int i = 0; i < m - 1; i++)
	{
		if(arr[i][j] != arr[i + 1][j])
		{
			return false;
		}
	}

	return true;
}

int main(int argc, char const *argv[])
{
	int arr[50][50];
	int m, n;

	cin >> m >> n;
	cout << endl;

	bool van = false;

	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cout << "arr["<<i<<"]["<<j<<"] = ";
			cin >> arr[i][j];
		}
	}

	cout << endl;

	for(int j = 0; j < n; j++)
	{
		if(egyenlo(j, m, arr))
		{
			cout << arr[0][j] << " ";
			van = true;
		}
	}

	if(!van)
	{
		cout << "Nu exista" << endl;
	}

	return 0;
}