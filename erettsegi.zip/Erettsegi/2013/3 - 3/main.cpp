#include <iostream>

using namespace std;

void valuri(int n, int v[])
{
	for(int i = 0; i <= (2 * n) - 2; i += 2)
	{
		v[i] = i + 1;
		v[i + 1] = (2 * n) - i;
	}
}

void kiir(int n, int v[])
{
	for(int i = 0; i < n; i++)
	{
		cout << v[i] << " ";
	}
}

int main(int argc, char const *argv[])
{
	int v[47];
	int n = 4;

	valuri(n, v);
	kiir(2 * n, v);

	return 0;
}