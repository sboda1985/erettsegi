#include <iostream>
#include <fstream>

using namespace std;

inline int elsoKetSzamjegyOsszege(int num)
{
	int ujNum = num / 1000;
	return (ujNum % 10) + (ujNum / 10);
}

inline int utolsoKetSzamjegyOsszege(int num)
{
	int ujNum = num % 100;
	return (ujNum % 10) + (ujNum / 10);
}

void kiIr(int s1, int s2)
{
	ofstream outputFile;
	outputFile.open("BAC.TXT");

	for(int i = 10000; i <= 99999; i++)
	{
		if(elsoKetSzamjegyOsszege(i) == s1 && utolsoKetSzamjegyOsszege(i) == s2)
		{
			outputFile << i << endl;
		}
	}

	outputFile.close();
}

int main(int argc, char const *argv[])
{
	int s1 = 18;
	int s2 = 18;

	kiIr(s1, s2);

	return 0;
}
