#include <iostream>
#include <fstream>

using namespace std;

void beOlvas(int &n, int a[])
{
	ifstream inputFile("input.in");
	inputFile >> n;

	int i = 0;
	while(inputFile >> a[i])
	{
		i++;
	}
}

void kiIr(int n, int a[])
{
	for(int i = 0; i < n; i++)
	{
		cout << a[i] << " ";
	}
}

void inserare(int &n, int a[])
{
	int i = 0;

	while(i < n)
	{
		if(a[i] % 2 == 0)
		{
			int j = n;
			n++;

			while(j > i)
			{
				a[j] = a[j - 1];
				j--;
			}

			i++;
			a[i] = 2011;
		}

		i++;
	}
}

int main(int argc, char const *argv[])
{
	int n ;
	int a[40];

	beOlvas(n, a);
	inserare(n, a);
	kiIr(n, a);

	return 0;
}
