#include <iostream>

using namespace std;

void sir(int n, int a[])
{
	a[0] = 1;
	a[1] = 1;

	for(int i = 2; i < n ; i++)
	{
		a[i] = (3 * a[i - 1]) - a[i - 2];
	}

	int i = 0;
	int j = n - 1;

	while(i < j)
	{
		if(a[i] % 2 == 0)
		{
			while(j > i && a[j] % 2 == 0)
			{
				j--;
			}

			swap(a[i], a[j]);
		}

		i++;
	}
}

int main(int argc, char const *argv[])
{
	int n = 6;
	int a[20];

	sir(n, a);

	for(int i = 0; i < n; i++)
	{
		cout << a[i] << " ";
	}

	return 0;
}