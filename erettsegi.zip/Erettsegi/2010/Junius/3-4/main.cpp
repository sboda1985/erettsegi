#include <iostream>
#include <fstream>

using namespace std;

int n;

void beOlvas(int &a, int &b, int &c)
{
	ifstream inputFile("bac.in");
	inputFile >> n;

	int data;

	a = 0;
	b = 0;
	c = 0;

	while(inputFile >> data)
	{
		if(data % 10 == 5)
		{
			if(data > a)
			{
				c = b;
				b = a;
				a = data;
				continue;
			}
			else
			{
				if(data > b)
				{
					c = b;
					b = data;
					continue;
				}
				else
				{
					if(data > c)
					{
						c = data;
						continue;
					}
					else
					{
						continue;
					}
				}
			}
		}
	}
}

int main(int argc, char const *argv[])
{
	int a;
	int b;
	int c;

	beOlvas(a, b, c);

	cout << c << " " << b << " " << a;

	return 0;
}