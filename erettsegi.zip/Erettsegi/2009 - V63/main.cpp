#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int kontor = 0;
    fstream inputFile("date.in.txt");

    if(inputFile.is_open())
    {
        int num1;
        int num2;
        int num3;

        inputFile >> num1;
        inputFile >> num2;
        inputFile >> num3;

        if(num2 < num1 + num3)
        {
            kontor++;
            cout << num2 << " ";
        }

        int temp;

        while(inputFile >> temp)
        {
            int copy3 = num3;
            int copy2 = num2;

            num3 = temp;
            num2 = copy3;
            num1 = copy2;

            if(num2 < num1 + num3)
            {
                kontor++;
                cout << num2 << " ";
            }
        }
    }

    cout << endl << kontor << endl;

    return 0;
}
