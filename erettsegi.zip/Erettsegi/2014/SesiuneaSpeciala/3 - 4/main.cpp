#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("bac.txt");

    int num;
    int prev = -1;
    int max = -1;
    int elem;

    while(inputFile >> num)
    {
        int k = 1;

        if(prev == num)
        {
            k++;
        }

        int next;

        while(inputFile >> next && num == next)
        {
            k++;
        }

        if(k >= max)
        {
            max = k;
            elem = num;
        }

        prev = next;
    }

    cout << max << endl;

    for(int i = 0; i < max; i++)
    {
        cout << elem << " ";
    }

    return 0;
}
