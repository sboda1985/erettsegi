#include <iostream>

using namespace std;

void perfect(int a, int b)
{
    bool van = false;

    for(int i = b; i >= a; i--)
    {
        int sum = 0;

        for(int j = 1; j <= i / 2; j++)
        {
            if(i % j == 0)
            {
                sum += j;
            }
        }

        if(sum == i)
        {
            van = true;
            cout << i << " ";
        }
    }

    if(!van)
    {
        cout << "Nu exista";
    }
}

int main()
{
    perfect(5, 30);
    return 0;
}
