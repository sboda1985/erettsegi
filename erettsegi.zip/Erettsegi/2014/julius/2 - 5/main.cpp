#include <iostream>

using namespace std;

int main()
{
    int m, n;

    cout << "m = ";
    cin >> m;

    cout << "n = ";
    cin >> n;

    int arr[m][n];

    cout << endl;

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cin >> arr[i][j];
        }
    }

    for(int i = 0; i < m; i++)
    {
        arr[i][n - 2] = -1;
    }

    for(int j = 0; j < n; j++)
    {
        arr[m - 2][j] = -1;
    }

    for(int i = 0; i < m; i++)
    {
        bool b = false;

        for(int j = 0; j < n; j++)
        {
            if(arr[i][j] != -1)
            {
                cout << arr[i][j] << " ";
                b = true;
            }
            else
            {
                continue;
            }
        }

        if(b)
        {
            cout << endl;
        }
        else
        {
            continue;
        }
    }

    return 0;
}
