#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int arr[90];

    for(int i = 0; i < 90; i++)
    {
        arr[i] = 0;
    }

    fstream inputFile("bac.txt");
    int num;

    while(inputFile >> num)
    {
        while(num > 9)
        {
            int x = num % 100;
            arr[x] += 1;
            num /= 10;
        }
    }

    int max = 0;

    for(int i = 0; i < 90; i++)
    {
        if(arr[i] > max)
        {
            max = arr[i];
        }
    }

    for(int i = 0; i < 90; i++)
    {
        if(arr[i] == max)
        {
            cout << i << " ";
        }
    }

    return 0;
}
