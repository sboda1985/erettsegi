#include <iostream>

using namespace std;

void interval(int n, int& a, int& b)
{
    a = n;

    int next = n + 1;
    int factorial = 1;

    for(int i = 1; i <= next; i++)
    {
        factorial *= i;
    }

    b = factorial - 1;
}

int main()
{
    int n = 4;
    int a, b;

    interval(n, a, b);

    cout << a << " " << b;

    return 0;
}
