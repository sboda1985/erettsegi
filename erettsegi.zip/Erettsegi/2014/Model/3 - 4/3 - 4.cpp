#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char const *argv[])
{
	ifstream inputFile("bac.txt");

	int n;
	int num = -1;
	int prevNum;
	int data;
	int firstNumber;
	int k = 0;

	inputFile >> n;

	while(k < n / 2 && inputFile >> data)
	{
		prevNum = num;
		num = data;

        inputFile >> data;

        k += 2;

		while(k < n / 2 && data == num)
		{
			inputFile >> data;
			k++;
		}

		num = data;
	}

	inputFile >> firstNumber;

	if(num == firstNumber)
	{
		if(prevNum > num)
		{
			cout << prevNum;
		}
		else
		{
			cout << "Nu exista";
		}
	}
	else
	{
		cout << num;
	}

	return 0;
}