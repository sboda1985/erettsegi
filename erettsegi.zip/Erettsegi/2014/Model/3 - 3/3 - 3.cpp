#include <iostream>

using namespace std;

void divizor(int n, int &d)
{
	for(int i = n; i >= 2; i--)
	{
		bool prim = true;

		int div = 2;

		while(div * div <= i)
		{
			if(i % div == 0)
			{
				prim = false;
				break;
			}

			div++;
		}

		if(prim && n % i == 0)
		{
			d = i;
			break;
		}
	}
}

int main(int argc, char const *argv[])
{
	int d = 2;

	divizor(50, d);

	cout << d;

	return 0;
}
