#include <iostream>

using namespace std;

int main()
{
    int m, n;

    cin >> m;
    cin >> n;

    int A[m][n];

    int curr = 2;

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            A[i][j] = curr;
            curr += 2;

            if(curr % 5 == 0)
            {
                curr += 2;
            }
            else
            {
                continue;
            }
        }
    }

    cout << endl;

    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cout << A[i][j] << " ";
        }

        cout << endl;
    }

    return 0;
}
