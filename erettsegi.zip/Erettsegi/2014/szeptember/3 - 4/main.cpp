#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream inputFile("bac.txt");

    int n;
    inputFile >> n;

    int arr[10];

    for(int i = 0; i < 10; i++)
    {
        arr[i] = 0;
    }

    int num;

    while(inputFile >> num)
    {
        int k = 0;

        while(num > 1)
        {
            num /= 10;
            k++;
        }

        arr[k]++;
    }

    int pos = 0;
    int index = 0;

    while(index < 10 && pos < n)
    {
        pos += arr[index];
        index++;
    }

    if(pos < n)
    {
        cout << "Nu exista";
    }
    else
    {
        int value = 1;

        for(int i = 0; i < index - 1; i++)
        {
            value *= 10;
        }

        cout << value;
    }

    return 0;
}
