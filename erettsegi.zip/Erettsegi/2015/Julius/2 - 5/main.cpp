#include <iostream>

using namespace std;

int main()
{
    int n;

    cout << "n = ";
    cin >> n;

    int arr[n][n];

    for(int i = 0; i < n; i++)
    {
        cin >> arr[0][i];
    }

    for(int i = 1; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            if(j == 0)
            {
                arr[i][j] = arr[i - 1][n - 1];
            }
            else
            {
                arr[i][j] = arr[i - 1][j - 1];
            }
        }
    }

    cout << endl;

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cout << arr[i][j] << " ";
        }

        cout << endl;
    }

    return 0;
}
