#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

int main()
{
    char a[20];
    char b[20];

    for(int i = 0; i < 20; i++)
    {
        a[i] = 0;
        b[i] = 0;
    }

    gets(b);

    for(int i = 0; i < strlen(b) / 2; i++)
    {
        a[i] = b[i];
    }

    cout << a;

    return 0;
}
