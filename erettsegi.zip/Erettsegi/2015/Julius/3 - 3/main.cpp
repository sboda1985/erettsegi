#include <iostream>

using namespace std;

int Fibo(int n)
{
    int prev1 = 1;
    int prev2 = 1;

    n -= 2;

    int curr = 1;

    while(n > 0)
    {
        curr = prev1 + prev2;

        if(curr % 2 == 1)
        {
            n--;
        }

        prev1 = prev2;
        prev2 = curr;
    }

    return curr;
}

int main()
{
    cout << Fibo(6);
    return 0;
}
