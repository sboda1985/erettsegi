#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("bac.txt");
    int num;
    int arr[100];

    for(int i = 0; i < 100; i++)
    {
        arr[i] = 0;
    }

    while(inputFile >> num)
    {
        arr[num] = 1;
    }

    bool kiir = true;
    bool van = false;

    for(int i = 0; i < 99; i++)
    {
        for(int j = i + 1; j < 100; j++)
        {
            if((j - i >= 2) && ((arr[i] == 1) && (arr[j] == 1)))
            {
                for(int k = i + 1; k < j; k++)
                {
                    if(arr[k] == 1)
                    {
                        kiir = false;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }

                if(kiir)
                {
                    cout << i << " " << j << endl;
                    van = true;
                }
                else
                {
                    kiir = true;
                }
            }
        }
    }

    if(!van)
    {
        cout << "nu exista" << endl;
    }

    return 0;
}
