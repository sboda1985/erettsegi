#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("BAC.txt");

    int n;
    inputFile >> n;

    int arr1[n];
    int arr2[n];

    int num;

    for(int i = 0; i < n; i++)
    {
        inputFile >> num;
        arr1[i] = num;
    }

    for(int i = 0; i < n; i++)
    {
        inputFile >> num;
        arr2[i] = num;
    }

    int sum = 0;

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            if((arr1[i] % 2 == 0 && arr2[j] % 2 != 0) || (arr1[i] % 2 != 0 && arr2[j] % 2 == 0))
            {
                sum += arr1[i] * arr2[j];
            }
            else
            {
                continue;
            }
        }
    }

    cout << sum;

    return 0;
}
