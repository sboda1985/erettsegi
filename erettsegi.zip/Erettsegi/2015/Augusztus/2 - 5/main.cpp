#include <iostream>

using namespace std;

int main()
{
    int k = 0;

    string word = "iii";
    string vowels = "aeou";

    bool boolValue = true;

    for(int i = 0; i < word.size(); i++)
    {
        for(int j = 0; j < vowels.size(); j++)
        {
            if(word[i] == vowels[j])
            {
                boolValue = false;
                break;
            }
            else if(word[i] == 'i')
            {
                k++;
                break;
            }
            else
            {
                continue;
            }
        }
    }

    if((!boolValue) || (k == word.size()))
    {
        cout << "NU";
    }
    else
    {
        cout << "DA";
    }

    return 0;
}
