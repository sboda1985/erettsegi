#include <iostream>

using namespace std;

int f(int n)
{
    int k = 0;
    bool prim = true;

    while(n != 0)
    {
        int temp = n % 10;

        for(int i = 2; i <= temp / 2; i++)
        {
            if(temp % i == 0)
            {
                prim = false;
                break;
            }
            else
            {
                continue;
            }
        }

        if(prim && temp != 0 && temp != 1)
        {
            k++;
        }
        else
        {
            prim = true;
        }

        n /= 10;
    }

    return k;
}

int main()
{
    cout << f(1233405);
    return 0;
}
