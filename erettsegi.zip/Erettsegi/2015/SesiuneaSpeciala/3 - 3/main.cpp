#include <iostream>

using namespace std;

int DivImpar(int a, int b)
{
    int max = 1;

    for(int i = 2; i <= a; i++)
    {
        if(a % i == 0 && b % i == 0 && i % 2 == 1)
        {
            max = i;
        }
    }

    return max;
}

int main()
{
    cout << DivImpar(3, 9);
    return 0;
}
