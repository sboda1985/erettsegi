#include <iostream>
#include <sstream>

using namespace std;

int main()
{
    string str;
    string temp;
    string szo = "";
    getline(cin, str);

    istringstream iss(str);

     while(iss >> temp)
     {
         if(temp[0] >= 'A' && temp[0] <= 'Z')
         {
             szo += temp[0];
         }
     }

     cout << szo;

    return 0;
}
