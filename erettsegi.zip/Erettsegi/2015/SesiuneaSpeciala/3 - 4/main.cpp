#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("date.in.txt");

    int num1, num2;
    int paros;
    int paratlan;
    int curr;

    inputFile >> num1;
    inputFile >> num2;

    if(num1 % 2 == 0)
    {
        paros = num1;
        paratlan = num2;
    }
    else
    {
        paratlan = num1;
        paros = num2;
    }

    bool van = true;

    while(inputFile >> curr)
    {
        if(curr % 2 == 0)
        {
            if(curr >= paros)
            {
                paros = curr;
                continue;
            }
            else
            {
                van = false;
                break;
            }
        }
        else
        {
            if(curr <= paratlan)
            {
                paratlan = curr;
                continue;
            }
            else
            {
                van = false;
                break;
            }
        }
    }

    if(van)
    {
        cout << "DA";
    }
    else
    {
        cout << "NU";
    }

    return 0;
}
