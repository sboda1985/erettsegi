#include <iostream>

using namespace std;

int kovetkezoSzam(int pos)
{
    int i = pos + 1;

    while(i % 3 == 0 || i % 2 == 0)
    {
        i++;
    }

    return i;
}

void kiIr(int m, int n, int A[20][20])
{
    for(int i = 0; i < m; i++)
    {
        for(int j = 0; j < n; j++)
        {
            cout << A[i][j] << " ";
        }

        cout << endl;
    }
}

int main()
{
    int A[20][20];
    int m, n;
    cin >> m;
    cin >> n;

    int num = 1;

    for(int i = m - 1; i >= 0; i--)
    {
        for(int j = n - 1; j >= 0; j--)
        {
            A[i][j] = num;
            num = kovetkezoSzam(num);
        }
    }

    kiIr(m, n, A);

    return 0;
}
