#include <iostream>
#include <fstream>

using namespace std;

void beOlvas(int &n, int &m, int arr[])
{
    ifstream inputFile("bac.txt");
    inputFile >> n;

    int num;
    m = 0;

    while(inputFile >> num)
    {
        arr[m] = num;
        m++;
    }
}

void rendez(int m, int arr[])
{
    for(int i = 0; i < m; i++)
    {
        int j = i;

        while(j > 0 && arr[j] > arr[j - 1])
        {
            int aux = arr[j];
            arr[j] = arr[j - 1];
            arr[j - 1] = aux;

            j--;
        }
    }
}

int keres(int n, int m, int arr[])
{
    if(n > m)
    {
        return -1;
    }
    else{
        return arr[n];
    }
}

int main()
{
    int n;
    int m;
    int arr[100000];

    beOlvas(n, m, arr);
    rendez(m, arr);
    cout << keres(n, m, arr);

    return 0;
}
