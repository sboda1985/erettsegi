#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("numere.in.txt");
    int n;
    int num;
    bool letezik = false;

    inputFile >> n;
    inputFile >> num;

    for(int i = 1; i <= n; i++)
    {
        while(i != num && i <= n)
        {
            cout << i << " ";
            i++;
            letezik = true;
        }

        int temp = num;
        inputFile >> num;

        while(num == temp && inputFile >> num)
        {
            continue;
        }
    }

    if(!letezik)
    {
        cout << "Nu exista" << endl;
    }

    return 0;
}
