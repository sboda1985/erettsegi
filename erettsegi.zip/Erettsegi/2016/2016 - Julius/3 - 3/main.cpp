#include <iostream>

using namespace std;

int cifreImpare(int n)
{
    int temp = n;
    int ujSzam = 0;
    int p = 1;
    int k = 0;

    while(temp != 0)
    {
        int szamjegy = temp % 10;

        if(szamjegy % 2 == 0)
        {
            ujSzam = ujSzam + szamjegy * p;
            p *= 10;
        }
        else
        {
            k++;
        }

        temp /= 10;
    }

    if(n == ujSzam)
    {
        return -1;
    }
    else if(ujSzam == 0)
    {
        return -1;
    }
    else
    {
        return ujSzam;
    }
}

int main()
{
    cout << cifreImpare(1357) << endl;
    return 0;
}
