#include <iostream>

using namespace std;

int main()
{
    char megengedettek[] = {'a', 'e', 'i', 'o', 'u'};
    char word[100];
    int n = 8;

    for(int i = 0; i < 100; i++)
    {
        word[i] = ' ';
    }

    for(int i = 0; i < n; i++)
    {
        cin >> word[i];
    }

    for(int i = 0; i < n; i++)
    {
        bool atalakitando = true;

        for(int j = 0; j < 5; j++)
        {
            if(word[i] == megengedettek[j] || word[i] == 'm')
            {
                atalakitando = false;
                break;
            }
        }

        if(atalakitando)
        {
            word[i] = ' ';
        }
    }

    bool van = false;

    for(int i = 0; i < n; i++)
    {
        if(word[i] != ' ')
        {
            cout << word[i];
            van = true;
        }
    }

    if(!van)
    {
        cout << "nu exista";
    }

    return 0;
}
