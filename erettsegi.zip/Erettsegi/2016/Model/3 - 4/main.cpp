#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream inputFile("date.txt");

    int num;
    int elozoParos = -1;
    int elozoParatlan = -1;

    bool helyes = true;

    while(inputFile >> num && helyes)
    {
        if(num % 2 == 0)
        {
            if(elozoParos == -1)
            {
                elozoParos = num;
            }
            else
            {
                if(num >= elozoParos)
                {
                    helyes = false;
                }
            }
        }
        else
        {
            if(elozoParatlan == -1)
            {
                elozoParatlan = num;
            }
            else
            {
                if(num <= elozoParatlan)
                {
                    helyes = false;
                }
            }
        }
    }

    if(helyes)
    {
        cout << "DA";
    }
    else
    {
        cout << "NU";
    }

    return 0;
}
