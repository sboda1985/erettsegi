#include <iostream>

using namespace std;

int main()
{
    int n;
    cin >> n;

    string arr[n];

    for(int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    int k;
    cin >> k;

    string sorozat[n];
    int a = 0;
    int b = n - 1;

    for(int i = 0; i < n; i++)
    {
        if(arr[i].size() == k)
        {
            sorozat[a] = arr[i];
            a++;
        }
        else
        {
            sorozat[b] = arr[i];
            b--;
        }
    }

    for(int i = 0; i < n; i++)
    {
        cout << sorozat[i] << " ";
    }

    return 0;
}
