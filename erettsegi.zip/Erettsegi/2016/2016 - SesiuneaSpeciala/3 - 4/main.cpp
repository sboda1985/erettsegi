#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    long long int num;

    cout << "num = ";
    cin >> num;

    fstream outputFile;

    outputFile.open("bac.out.txt");

    for(int i = num; i > 0; i--)
    {
        int f = i;

        if(i % 2 == 0)
        {
            f = (f / 2) * (-1);
            outputFile << f << " ";
        }
        else
        {
            f = (f / 2) + 1;
            outputFile << f << " ";
        }
    }

    outputFile.close();

    return 0;
}
