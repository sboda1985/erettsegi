#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream inputFile("bac.txt");
    int num;
    int paros1 = -1;
    int paros2 = -1;
    int k = 0;

    while(inputFile >> num && k <= 3)
    {
        if(num % 2 == 0 && k == 3)
        {
            if(num > paros1 || num > paros2)
            {
                if(paros1 > paros2)
                {
                    paros2 = num;
                }
                else
                {
                    paros1 = num;
                }
            }
        }

        if(num % 2 == 1)
        {
            k++;
        }
    }

    if(paros1 == -1 || paros2 == -1)
    {
        cout << "Nu exista";
    }
    else
    {
        if(paros1 > paros2)
        {
            cout << paros2 << " " << paros1 << endl;
        }
        else
        {
            cout << paros1 << " " << paros2 << endl;
        }
    }

    return 0;
}
