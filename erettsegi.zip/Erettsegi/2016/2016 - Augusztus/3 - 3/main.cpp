#include <iostream>

using namespace std;

void duplicare(int n, int &d)
{
    int p = 1;
    int temp = n;
    d = 0;

    while(temp != 0)
    {
        int szamjegy = temp % 10;

        d += szamjegy * p;
        p *= 10;

        if(szamjegy % 2 == 0)
        {
            d += szamjegy * p;
            p *= 10;
        }

        temp /= 10;
    }

    if(d == n)
    {
        d = -1;
    }
}

int main()
{
    int n = 31457;
    int d;

    duplicare(n, d);

    cout << d << endl;

    return 0;
}
